# Summer Hack Club Project
- Unzip and run library.app.
- Requires macOS 10.15+.
